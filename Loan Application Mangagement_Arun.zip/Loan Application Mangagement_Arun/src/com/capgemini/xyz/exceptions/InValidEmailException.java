package com.capgemini.xyz.exceptions;

public class InValidEmailException  extends RuntimeException{

	public InValidEmailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InValidEmailException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InValidEmailException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InValidEmailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InValidEmailException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
