package com.capgemini.xyz.exceptions;

public class InvalidMobileNoException extends RuntimeException {

	public InvalidMobileNoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidMobileNoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
